####Speech recognition

Using the Mac OS speech recognition API required a program writted in Objective-C or Swift. This is a very basic swift program that listens for the word "bookmark" and runs a script to add a bookmark in iBooks.
